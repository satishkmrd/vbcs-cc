define(['ojs/ojlistdataproviderview', 'ojs/ojdataprovider'], (ListDataProviderView, ojdataprovider_1) => {
  'use strict';
  class PageModule {
    createLDPV(ADP, filter) {
      let filterCriterion = null;
      if (filter && filter != '') {
        filterCriterion = ojdataprovider_1.FilterFactory.getFilter({
          filterDef: { text: filter } //This is text filter

          // --- Below is ExtendedCompoundFilterDef where we can specify the columns to filter on ---
          // filterDef: { op: '$or', criteria: [{ op: '$co', value: { fIRSTNAME: filter } } , { op: '$co', value: { lASTNAME: filter } }]}

        });
      }
      return new ListDataProviderView(ADP, { filterCriterion: filterCriterion });
    }
  }
  return PageModule;
});