define([], () => {
  'use strict';

  class PageModule {
    ParseData(file) {
      return new Promise(function (resolve, reject) {
        let fileReader = new FileReader();
        fileReader.readAsText(file);
        fileReader.onload = (event) => {
          let data = event.target.result;
          const parser = new fxp.XMLParser();
          let result;
          try {
            result = parser.parse(data);
            console.log(result);
            resolve(result);
          } catch (err) {
            console.log(err);
            reject(err);
          }
        };
      });
    }
  }
  return PageModule;
});
