define(['resources/js/jszip.min'], (jszip) => {
  'use strict';

  class PageModule {

    getBase64(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.split(',').pop());
        reader.onerror = error => reject(error);
      });
    }

    // preparePayload(FileUpload, DocumentAccount, base64Content) {

    //   let obj = {};
    //   obj.OperationName = 'uploadFileToUCM';
    //   obj.DocumentContent = base64Content;
    //   obj.DocumentAccount = DocumentAccount;
    //   obj.ContentType = FileUpload.Type;
    //   obj.FileName = FileUpload.Name;

    //   return obj;
    // }

    preview(blobData, contentType) {
      if (contentType === undefined || contentType.length === 0) {
        contentType = "application/octet-stream";
      }
      var newBlob = new Blob([blobData], {
        type: contentType
      });
      return URL.createObjectURL(newBlob);
    };

    zip(FileUpload, DocumentAccount, base64Content) {
      const zip = new jszip();
      zip.file("GlDailyRatesInterface.PROPERTIES", "/oracle/apps/ess/financials/generalLedger/programs/common,DailyRatesImport,GlDailyRatesInterface");
      //const img = zip.folder("images");
      zip.file("GlDailyRatesInterface.csv", base64Content, { base64: true });
      zip.generateAsync({ type: "blob" }).then(function (content) {
        let element = document.createElement('a');
        let date = new Date().toJSON().slice(0,10).replace(/-/g,'_');
        element.setAttribute('href', PageModule.prototype.preview(content, ''));
        element.setAttribute('download', "GlDailyRatesInterface_"+date+".zip");
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
      });
    }
  }

  return PageModule;
});
