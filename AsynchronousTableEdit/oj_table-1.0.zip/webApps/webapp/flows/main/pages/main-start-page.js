define([], () => {
  'use strict';

  class PageModule {
    constructor(context) {
      this.eventHelper = context.getEventHelper();
    }

    lineTableBeforeRowEdit(event) {
      let detail = event.detail;
      event.detail.accept(new Promise(function (resolve) {
        this.rowBeforeEditPromise = resolve;
        this.eventHelper.fireCustomEvent("tableBeforeRowEdit", {
          "detail": event.detail
        });
        // reject(); when required
      }.bind(this)));
    }

    resolveRowBeforeEditPromise() {
      if (this.rowBeforeEditPromise) {
        this.rowBeforeEditPromise();
        delete this.rowBeforeEditPromise;
      }
    }
  }
  
  return PageModule;
});
