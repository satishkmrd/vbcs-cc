define(['xlsx'], (XLSX) => {
  'use strict';

  class PageModule {
    ParseData(file) {
      return new Promise(function (resolve, reject) {
        let fileReader = new FileReader();
        fileReader.readAsBinaryString(file);
        fileReader.onload = (event) => {
          let data = event.target.result;
          let workbook = XLSX.read(data, { type: "binary" });
          workbook.SheetNames.forEach(sheet => {
            if (sheet == 'Sheet1') {
              let rowObject = XLSX.utils.sheet_to_json(workbook.Sheets[sheet]);
              console.log(rowObject);
              resolve(rowObject);
            }
          });
        };
      });
    }
  }
  return PageModule;
});
