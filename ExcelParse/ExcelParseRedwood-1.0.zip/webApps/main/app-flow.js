define(['oj-sp/spectra-shell/config/config'], function() {
  'use strict';

  class AppModule {
  }
  
  return AppModule;
});
