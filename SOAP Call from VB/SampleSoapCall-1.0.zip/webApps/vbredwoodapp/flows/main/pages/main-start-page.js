define(['vb/helpers/rest', 'papa'], (Rest, Papa) => {
  'use strict';

  class PageModule {

    callBIP() {
      return new Promise(function (resolve, reject) {
        let soapRequest = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">\
                                  <soap:Header/>\
                                  <soap:Body>\
                                    <pub:runReport>\
                                    <pub:reportRequest>\
                                    <pub:parameterNameValues>\
                                    </pub:parameterNameValues>\
                              <pub:reportAbsolutePath>/Custom/SOAPDemo/DemoRPT.xdo</pub:reportAbsolutePath>\
                              <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>\
                        </pub:reportRequest>\
                        </pub:runReport>\
                      </soap:Body>\
                    </soap:Envelope>';
        console.log(soapRequest);
        Rest.get('ExternalReportWSSService/postXmlpserverServicesExternalReportWSSService').body(soapRequest).fetch().then(
          response => {
            let xmlResponse = $.parseXML(response.body);
            let reportBytes = xmlResponse.getElementsByTagNameNS("*", "reportBytes")[0].textContent;
            resolve(reportBytes);
          });
      });
    }

    parseCSV(reportOutput) {
      let Output = decodeURIComponent(window.escape(atob(reportOutput)));
      let response = Papa.parse(Output.trim(), { header: true });
      console.log(response.data);
      return response.data;
    }
  }

  return PageModule;
});
