define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const callBIPResponse = await $functions.callBIP();

      const parsedData = await $functions.parseCSV(callBIPResponse);

      await Actions.fireDataProviderEvent(context, {
        target: $variables.DemoADP,
        add: {
          data: parsedData,
        },
      });
    }
  }

  return ButtonActionChain;
});
