define(['papa'], (Papa) => {
  'use strict';

  class PageModule {

    ParseData(file) {

      //Sample For Parsing CSV which is String
      console.log(Papa.parse('a,c,b'));

      //Since parsing a file is Asyn we return a promise
      return new Promise(function (resolve, reject) {
        // For Parsing a File
        Papa.parse(file, {
          complete: function (results) {
            console.log(results.data);
            resolve(results.data);
          },
          header: true
        });
      });
    }
  }

  return PageModule;
});
