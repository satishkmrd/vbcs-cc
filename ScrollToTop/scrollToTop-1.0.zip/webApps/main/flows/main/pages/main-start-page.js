define([], () => {
  'use strict';

  class PageModule {
}

window.onscroll = function () { scrollFunction() };

function scrollFunction() {
    let topButton = document.getElementById("GoToTopBtn");
    if (topButton) {
      topButton.addEventListener("click", () => {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
      });
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        topButton.style.display = "block";
      } else {
        topButton.style.display = "none";
      }
    }
  }

return PageModule;
});
