define([], () => {
  'use strict';

  class PageModule {

    getBase64(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.split(',').pop());
        reader.onerror = error => reject(error);
      });
    }

    preparePayload(FileUpload, DocumentAccount, base64Content) {
      
      let obj = {};
      obj.OperationName = 'uploadFileToUCM';
      obj.DocumentContent = base64Content;
      obj.DocumentAccount = DocumentAccount;
      obj.ContentType = FileUpload.Type;
      obj.FileName = FileUpload.Name;

      return obj;
    }
  }

  return PageModule;
});
