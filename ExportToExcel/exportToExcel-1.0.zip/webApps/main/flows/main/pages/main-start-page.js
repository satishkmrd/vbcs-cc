define(['xlsx'], (XLSX) => {
  'use strict';

  class PageModule {

    generateExcel(data1, data2) {

      let wb = XLSX.utils.book_new();
      wb.Props = {
        Title: "Export as Multiple Sheets",
        Subject: "Demo",
        Author: "Satish Kumar",
        CreatedDate: new Date()
      };

      wb.SheetNames.push("data1");
      let ws1 = XLSX.utils.json_to_sheet(data1.Employees);
      wb.Sheets["data1"] = ws1;

      wb.SheetNames.push("data2");
      let ws2 = XLSX.utils.json_to_sheet(data2.Departments);
      wb.Sheets["data2"] = ws2;

      let wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

      function s2ab(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i < s.length; i++) view[i] = s
          .charCodeAt(i) & 0xFF;
        return buf;
      }

      this.download(s2ab(wbout), '', 'demo.xlsx');

    };

    preview(blobData, contentType) {
      if (contentType === undefined || contentType.length === 0) {
        contentType = "application/octet-stream";
      }
      var newBlob = new Blob([blobData], {
        type: contentType
      });
      return URL.createObjectURL(newBlob);
    };

    download(blobData, contentType, fileName) {
      var element = document.createElement('a');
      element.setAttribute('href', this.preview(blobData, contentType));
      element.setAttribute('download', fileName);
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    };
  }

  return PageModule;
});
